const bcrypt = require('bcrypt'); // Importing bcrypt for password hashing
const jwt = require('jsonwebtoken'); // Importing jsonwebtoken for generating tokens
const nodemailer = require('nodemailer'); // Importing nodemailer for sending emails
const User = require('../models/userModel'); // Importing the User model
const { emailConfig, jwtSecret } = require('../config/config'); // Importing email configuration and JWT secret
const { promisify } = require('util'); // Import the promisify function from the util module
const fs = require('fs');
// Promisify fs.unlink to delete files asynchronously
const unlinkAsync = promisify(fs.unlink); // Importing fs module for file operations and promisify unlink function

/**
 * Controller function to handle user registration
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 */
const registerUser = async (req, res) => {
  try {
    const { name, email, password } = req.body; // Extracting name, email, and password from request body

    // Check if email is already registered
    let existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(400).json({ message: 'Email already exists' }); // Return error if email already exists
    }

    // Hash the password
    const hashedPassword = await bcrypt.hash(password, 10); // Hash the password using bcrypt lib..

    // Save user to database
    const user = new User({
      name,
      email,
      password: hashedPassword,
      profilePicture: req.file ? req.file.filename : null // Store filename if profile picture is uploaded
    });
    await user.save(); // Save the user to the database

    // Send confirmation email
    await sendConfirmationEmail(email); // Send confirmation email to the registered email address

    res.status(201).json({ message: 'User registered successfully' }); // Return success message
  } catch (error) {
    console.error(error); // Log any errors
    res.status(500).json({ message: 'Internal server error' }); // Return error response
  }
};

/**
 * Function to send confirmation email to the provided email address
 * @param {string} email =- Email address to send the confirmation email
 */
const sendConfirmationEmail = async (email) => {
  console.log(email);
  try {
    const transporter = nodemailer.createTransport(emailConfig); // Create nodemailer transporter using email configuration

    const token = jwt.sign({ email }, jwtSecret, { expiresIn: '1d' });


    const confirmationUrl = `http://example.com/confirm?token=${token}`; // URL for email confirmation use like gmail or 

    await transporter.sendMail({
      from: emailConfig.auth.user,
      to: email,
      subject: 'Registration Confirmation',
      text: `Please click the following link to confirm your email address: ${confirmationUrl}` // Email body with confirmation link
    });

    console.log('Confirmation email sent'); // Log confirmation email sent
  } catch (error) {
    console.error('Error sending confirmation email:', error); // Log error if confirmation email fails to send
  }
};

module.exports = { registerUser }; // Exporting the registerUser function
