const multer = require('multer');
const path = require('path');

const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'uploads/'); // Set destination folder for file uploads
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + path.extname(file.originalname)); // Setting the filename with current timestamp and original extension
  }
});

const upload = multer({ 
  storage: storage,
  limits: {
    fileSize: 1024 * 1024 * 5 // Setting up the file size limit to 5MB
  },
  fileFilter: function(req, file, cb) {
    checkFileType(file, cb); // Filtering files based on allowed file types
  }
});

function checkFileType(file, cb) {
  const filetypes = /jpeg|jpg|png/; // Allowing the file types
  const extname = filetypes.test(path.extname(file.originalname).toLowerCase()); // Check file extension
  const mimetype = filetypes.test(file.mimetype); // Check file mimetype
  if (mimetype && extname) {
    return cb(null, true); // File type is allowed
  } else {
    cb('Error: Images only (JPEG/JPG/PNG)!'); // Error for invalid file type
  }
}

module.exports = upload;
