const express = require('express');
const mongoose = require('mongoose');
require('dotenv').config(); // Load the environment variables from .env file
const userRoutes = require('./routes/userRoutes');


const jwtSecret = process.env.jwtSecret;
console.log('jwtSecret:', process.env.jwtSecret);
const app = express();
mongoose.connect(process.env.MONGODB_URI)
  .then(() => console.log('Connected to MongoDB'))
  .catch(error => console.error('MongoDB connection error:', error));

app.use(express.json());

app.use('/api', userRoutes);

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
