const nodemailer = require('nodemailer'); // Importing nodemailer for sending emails
const { emailConfig } = require('../config/config'); // Importing email configuration

/**
 * Function to send confirmation email to the provided email address
 * @param {string} email - Email address to send the confirmation email
 */

const sendConfirmationEmail = async (email) => {
  try {
    const transporter = nodemailer.createTransport(emailConfig); // Createing nodemailer transporter using email configuration

    // Sending the  confirmation email
    await transporter.sendMail({
      from: emailConfig.auth.user, // Set sender email address
      to: email, // Set recipient email address
      subject: 'Registration Confirmation', // Set email subject
      text: 'Thank you for registering. Your account has been successfully created.' // Set email body
    });

    console.log('Confirmation email sent'); // Loging  confirmation email sent
  } catch (error) {
    console.error('Error sending confirmation email:', error); // Loging error if confirmation email fails to send
  }
};

module.exports = { sendConfirmationEmail }; // Exporting the sendConfirmationEmail function

