const { body, validationResult } = require('express-validator');
const { registerUser } = require('../controllers/userController');
const express = require('express');
const router = express.Router();
const upload = require('../config/multerConfig'); // Import multer instance

router.post(
  '/register',
  upload.single('profilePicture'), // Handling single file upload for profile picture
  [
    body('name').notEmpty().withMessage('Name is required'),
    body('email').isEmail().withMessage('Invalid email address'),
    body('password').isLength({ min: 6 }).withMessage('Password must be at least 6 characters long')
  ],
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }
    registerUser(req, res);
  }
);

module.exports = router;
