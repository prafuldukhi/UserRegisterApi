const mongoose = require('mongoose'); // Importing mongoose for MongoDB object modeling

// Define the schema for the User model
const userSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true // Name field is required
  },
  email: {
    type: String,
    required: true,
    unique: true // Email field is required and must be unique
  },
  password: {
    type: String,
    required: true // Password field is required
  },
  profilePicture: {
    type: String // Store the file path or URL of the profile picture
  },
  emailConfirmed: {
    type: Boolean,
    default: false // Email confirmation status, default is false
  }
});

// Creating a mongoose model for the User schema
const User = mongoose.model('User', userSchema);

module.exports = User; // Export the User model

